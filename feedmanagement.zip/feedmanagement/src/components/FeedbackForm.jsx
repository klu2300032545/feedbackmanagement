import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./FeedbackForm.css";

const facultyData = [
  { name: "Anil", subject: "English" },
  { name: "Kumar", subject: "Mathematics-1" },
  { name: "Phani", subject: "Solid State Physics" },
  { name: "Praveen", subject: "Information Technology & Numerical Methods" },
  { name: "Raja", subject: "Electronic Devices and Circuits" },
  { name: "Ram", subject: "Engineering Drawing Practice" },
  { name: "Revanth", subject: "C & Data structures" },
  { name: "Sai", subject: "Electronic Devices & Circuits Lab" },
  { name: "Sajith", subject: "Network Theory" },
  { name: "Satish", subject: "Computer Programming Lab" },
];

function FeedbackForm() {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowModal(true);
  };

  const confirmSubmit = () => {
    setShowModal(false);
    navigate("/success");
  };

  return (
    <div className="feedback-container">
      <h1>STUDENT FEEDBACK SYSTEM</h1>
      <form onSubmit={handleSubmit}>
        <table className="feedback-table">
          <thead>
            <tr>
              <th>Excellent</th>
              <th>Very Good</th>
              <th>Good</th>
              <th>Satisfactory</th>
              <th>Not Satisfactory</th>
              <th>Faculty Name</th>
              <th>Subject</th>
            </tr>
          </thead>
          <tbody>
            {facultyData.map((item, index) => (
              <tr key={index}>
                {[...Array(5)].map((_, i) => (
                  <td key={i}>
                    <input type="radio" name={`rating-${index}`} />
                  </td>
                ))}
                <td>{item.name}</td>
                <td>{item.subject}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="submit-container">
          <button type="submit">Submit</button>
        </div>
      </form>

      {showModal && (
        <div className="modal">
          <div className="modal-box">
            <p>Are you sure you want to submit?</p>
            <button onClick={confirmSubmit}>Yes</button>
            <button onClick={() => setShowModal(false)}>No</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default FeedbackForm;
