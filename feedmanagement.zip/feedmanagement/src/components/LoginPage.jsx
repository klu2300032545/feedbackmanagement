import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css";
import labImage from "../assets/lab.jpg";

function LoginPage() {
  const [regNumber, setRegNumber] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (regNumber && password) {
      navigate("/feedback");
    } else {
      alert("Please enter registration number and password");
    }
  };

  return (
    <div className="login-container" style={{ backgroundImage: `url(${labImage})` }}>
      <div className="login-box">
        <h2>Student Feedback System</h2>
        <form onSubmit={handleLogin}>
          <input
            type="text"
            placeholder="Registration Number"
            value={regNumber}
            onChange={(e) => setRegNumber(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}

export default LoginPage;
