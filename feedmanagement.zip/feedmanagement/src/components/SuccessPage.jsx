import React from "react";
import "./SuccessPage.css";

function SuccessPage() {
  return (
    <div className="success-container">
      <div className="navbar">
        <button>Home</button>
        <button>Feedback</button>
        <button>Change Password</button>
        <button>Logout</button>
      </div>
      <div className="success-content">
        <h2>FeedBack Submitted Successfully</h2>
      </div>
    </div>
  );
}

export default SuccessPage;
