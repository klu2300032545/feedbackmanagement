package com.klu.student_feedback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
