package Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class Feedback {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private int rating;
	    private String comments;

	    @ManyToOne
	    private User student;

	    @ManyToOne
	    private Faculty faculty;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public int getRating() {
			return rating;
		}

		public void setRating(int rating) {
			this.rating = rating;
		}

		public String getComments() {
			return comments;
		}

		public void setComments(String comments) {
			this.comments = comments;
		}

		public User getStudent() {
			return student;
		}

		public void setStudent(User student) {
			this.student = student;
		}

		public Faculty getFaculty() {
			return faculty;
		}

		public void setFaculty(Faculty faculty) {
			this.faculty = faculty;
		}
	}

