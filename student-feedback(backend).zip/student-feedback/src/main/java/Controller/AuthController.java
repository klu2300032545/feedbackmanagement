package Controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Repository.UserRepository;
import Service.JwtService;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserRepository userRepository = null;
    private final JwtService jwtService = null;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> loginData) {
        String regNumber = loginData.get("regNumber");
        String password = loginData.get("password");

        return userRepository.findByRegNumberAndPassword(regNumber, password)
                .map(user -> {
                    String token = jwtService.generateToken(user.getRegNumber());
                    return ResponseEntity.ok(Map.of(
                        "token", token,
                        "userId", user.getId(),
                        "role", user.getRole()
                    ));
                })
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("error", "Invalid credentials")));
    }
}
