package Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import java.util.List;

import Model.Feedback;
import Model.Faculty;
import Model.User;
import DTO.FeedbackRequest;
import Repository.FeedbackRepository;
import Repository.FacultyRepository;
import Repository.UserRepository;

@RestController
@RequestMapping("/api/feedback")
@RequiredArgsConstructor
public class FeedbackController {

    private final FeedbackRepository feedbackRepository = null;
    private final FacultyRepository facultyRepository =null;
    private final UserRepository userRepository=null;

    @PostMapping("/submit")
    public ResponseEntity<String> submitFeedback(@RequestBody List<FeedbackRequest> feedbackList) {
        for (FeedbackRequest fr : feedbackList) {
            User student = userRepository.findById(fr.getStudentId())
                    .orElseThrow(() -> new RuntimeException("Student not found"));

            Faculty faculty = facultyRepository.findByNameAndSubject(fr.getFacultyName(), fr.getSubject())
                    .orElseThrow(() -> new RuntimeException("Faculty not found"));

            Feedback feedback = new Feedback();
            feedback.setStudent(student);
            feedback.setFaculty(faculty);
            feedback.setRating(fr.getRating());
            feedback.setComments(fr.getComments());

            feedbackRepository.save(feedback);
        }
        return ResponseEntity.ok("Feedback submitted");
    }
}
        

    

