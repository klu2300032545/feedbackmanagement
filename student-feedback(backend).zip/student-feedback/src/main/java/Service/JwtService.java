package Service;


	import io.jsonwebtoken.*;
	import io.jsonwebtoken.security.Keys;
	import org.springframework.stereotype.Service;

	import java.security.Key;
	import java.util.Date;

	@Service
	public class JwtService {

	    private final String SECRET = "your_secret_key_here_which_should_be_long_enough";
	    private final long EXPIRATION_TIME = 1000 * 60 * 60; // 1 hour

	    private Key getSigningKey() {
	        return Keys.hmacShaKeyFor(SECRET.getBytes());
	    }

	    public String generateToken(String regNumber) {
	        return Jwts.builder()
	                .setSubject(regNumber)
	                .setIssuedAt(new Date())
	                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
	                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
	                .compact();
	    }

	    public String extractUsername(String token) {
	        return Jwts.parserBuilder()
	                .setSigningKey(getSigningKey())
	                .build()
	                .parseClaimsJws(token)
	                .getBody()
	                .getSubject();
	    }

	    public boolean validateToken(String token) {
	        try {
	            Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token);
	            return true;
	        } catch (JwtException e) {
	            return false;
	        }
	    }
	}


